create view ADMINISTRABLE_ROLE_AUTHORIZATIONS as
select `applicable_roles`.`USER`         AS `USER`,
       `applicable_roles`.`HOST`         AS `HOST`,
       `applicable_roles`.`GRANTEE`      AS `GRANTEE`,
       `applicable_roles`.`GRANTEE_HOST` AS `GRANTEE_HOST`,
       `applicable_roles`.`ROLE_NAME`    AS `ROLE_NAME`,
       `applicable_roles`.`ROLE_HOST`    AS `ROLE_HOST`,
       `applicable_roles`.`IS_GRANTABLE` AS `IS_GRANTABLE`,
       `applicable_roles`.`IS_DEFAULT`   AS `IS_DEFAULT`,
       `applicable_roles`.`IS_MANDATORY` AS `IS_MANDATORY`
from `information_schema`.`APPLICABLE_ROLES`
where (`applicable_roles`.`IS_GRANTABLE` = 'YES');

